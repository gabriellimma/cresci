package br.com.cresci.Cresci;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CresciApplicationTests {

	@Test
	void contextLoads() {
	}

}
