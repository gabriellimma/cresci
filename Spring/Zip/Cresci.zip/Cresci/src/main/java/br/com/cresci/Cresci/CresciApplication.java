package br.com.cresci.Cresci;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CresciApplication {

	public static void main(String[] args) {
		SpringApplication.run(CresciApplication.class, args);
	}

}
